from .serializers import UserSerializer
from .views import UserList, UserRetrieve
